
import { PrismaClient } from '@prisma/client'
import * as bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

const categories = [
  { es: 'Plomería', en: 'Plumbing', slug: 'plomeria', icon: 'wrench', syn: ['plomero','plomeria'] },
  { es: 'Electricidad', en: 'Electricity', slug: 'electricidad', icon: 'zap', syn: ['electricista','electricidad'] },
  { es: 'Carpintería', en: 'Carpentry', slug: 'carpinteria', icon: 'hammer', syn: ['carpintero'] },
  { es: 'Barbería', en: 'Barbershop', slug: 'barberia', icon: 'scissors', syn: ['barbero','barber'] },
  // ... we can add the full long list later; keeping the seed light for first run
]

async function main() {
  // Seed admin
  const adminUser = process.env.ADMIN_USERNAME || 'serbizadmin1'
  const adminPass = process.env.ADMIN_PASSWORD || 'SERBIZ09!'
  const hash = bcrypt.hashSync(adminPass, 10)

  await prisma.user.upsert({
    where: { username: adminUser },
    update: { password: hash, role: 'ADMIN' },
    create: { username: adminUser, password: hash, role: 'ADMIN', locale: process.env.DEFAULT_LOCALE as any || 'es' }
  })

  // Seed categories
  for (const c of categories) {
    await prisma.category.upsert({
      where: { slug: c.slug },
      update: { name_es: c.es, name_en: c.en, iconKey: c.icon, synonyms: c.syn },
      create: { name_es: c.es, name_en: c.en, slug: c.slug, iconKey: c.icon, synonyms: c.syn }
    })
  }

  console.log('Seed done.')
}

main().catch(e => { console.error(e); process.exit(1) }).finally(async () => { await prisma.$disconnect() })
