import { db } from '@/lib/db'
import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth'

export default async function AdminPage(){
  const session = await getSession()
  if (!session.user || session.user.role !== 'admin') redirect('/login')
  const vendors = await db.vendor.findMany({ include: { category: true }, orderBy: { createdAt: 'desc' } })
  const users = await db.user.findMany({ orderBy: { createdAt: 'desc' } })
  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold">Admin</h1>
      <section>
        <h2 className="font-semibold mb-2">Usuarios</h2>
        <div className="grid md:grid-cols-2 gap-2">
          {users.map(u => (
            <div key={u.id} className="card">
              <div className="font-semibold">{u.username}</div>
              <div className="text-sm opacity-70">{u.role}</div>
            </div>
          ))}
        </div>
      </section>
      <section>
        <h2 className="font-semibold mb-2">Proveedores</h2>
        <div className="grid md:grid-cols-2 gap-2">
          {vendors.map(v => (
            <div key={v.id} className="card">
              <div className="font-semibold">{v.businessName}</div>
              <div className="text-sm opacity-70">{v.category?.name_es} · {v.province}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
