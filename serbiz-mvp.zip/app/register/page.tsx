import { register } from '@/lib/auth'
import { redirect } from 'next/navigation'

export default function RegisterPage(){
  async function action(formData: FormData){
    'use server'
    const username = String(formData.get('username')||'')
    const password = String(formData.get('password')||'')
    const role = String(formData.get('role')||'user') as 'user'|'vendor'
    const res = await register(username,password,role)
    if(!res.ok) return {error: res.error}
    redirect(role==='vendor'?'/dashboard/vendor':'/')
  }
  return (
    <form action={action} className="max-w-md mx-auto card space-y-3 mt-6">
      <h1 className="text-xl font-bold">Crear cuenta</h1>
      <input className="input" name="username" placeholder="Usuario" required />
      <input className="input" name="password" placeholder="Contraseña" type="password" required />
      <select name="role" className="input">
        <option value="user">Usuario</option>
        <option value="vendor">Proveedor</option>
      </select>
      <button className="btn btn-primary w-full">Crear</button>
    </form>
  )
}
