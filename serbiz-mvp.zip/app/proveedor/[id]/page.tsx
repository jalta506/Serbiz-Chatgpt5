import { db } from '@/lib/db'
import VendorCard from '@/components/VendorCard'

export default async function VendorPublic({ params }:{ params: { id: string }}){
  const vendor = await db.vendor.findUnique({ where: { id: params.id }, include: { category: true } })
  if (!vendor) return <div className="mt-8">No encontrado</div>
  return (
    <div className="max-w-2xl mx-auto">
      <VendorCard vendor={vendor} />
      <div className="mt-6 card">
        <h2 className="font-semibold mb-2">Descripción</h2>
        <p className="text-sm text-black/70">Proveedor en {vendor.province}, {vendor.canton}, {vendor.district}.</p>
      </div>
    </div>
  )
}
