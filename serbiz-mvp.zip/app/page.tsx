import SearchBar from '@/components/SearchBar'
import { db } from '@/lib/db'
import VendorCard from '@/components/VendorCard'
import { t } from '@/lib/i18n'

export default async function Home() {
  const locale = (process.env.DEFAULT_LOCALE as 'es'|'en') || 'es'
  const vendors = await db.vendor.findMany({ include: { category: true }, take: 8, orderBy: { createdAt: 'desc' } })

  return (
    <div className="space-y-8">
      <section className="rounded-2xl p-8 bg-turquoise">
        <h1 className="text-3xl md:text-4xl font-extrabold">{
          t(locale, 'banner')
        }</h1>
        <p className="mt-2 text-black/70">SERBIZ · Turquoise & Black · Mobile-first</p>
        <div className="mt-6"><SearchBar /></div>
      </section>

      <section className="space-y-4">
        <h2 className="text-xl font-bold">Nuevos proveedores</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {vendors.map(v => (<VendorCard key={v.id} vendor={v} locale={locale} />))}
        </div>
      </section>
    </div>
  )
}
