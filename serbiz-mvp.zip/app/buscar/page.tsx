import { db } from '@/lib/db'
import VendorCard from '@/components/VendorCard'

export default async function Buscar({ searchParams }:{ searchParams: { q?: string, loc?: string }}){
  const q = (searchParams.q || '').trim()
  const loc = (searchParams.loc || '').trim()

  const vendors = await db.vendor.findMany({
    where: {
      isPublished: true,
      OR: [
        { businessName: { contains: q, mode: 'insensitive' } },
        { tags: { has: q.toLowerCase() } },
        { category: { name_es: { contains: q, mode: 'insensitive' } } },
      ],
      ...(loc ? { OR: [
        { province: { contains: loc, mode: 'insensitive' } },
        { canton: { contains: loc, mode: 'insensitive' } },
        { district: { contains: loc, mode: 'insensitive' } },
      ] } : {})
    },
    include: { category: true },
    take: 50
  })

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold">Resultados</h1>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {vendors.map(v => <VendorCard key={v.id} vendor={v} />)}
      </div>
    </div>
  )
}
