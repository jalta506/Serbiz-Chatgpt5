import Link from 'next/link'
import { t } from '@/lib/i18n'

export default function VendorCard({ locale='es', vendor }:{ locale?:'es'|'en', vendor:any }){
  const wa = `https://wa.me/${vendor.whatsapp.replace(/[^0-9]/g,'')}`
  return (
    <div className="card">
      <div className="flex items-center gap-3">
        <div className="size-12 rounded-xl bg-turquoise/20 flex items-center justify-center font-bold">{vendor.businessName[0] || 'S'}</div>
        <div className="flex-1">
          <div className="font-semibold">{vendor.businessName}</div>
          <div className="text-sm text-black/60">{vendor.category?.name_es} · {vendor.province}{vendor.allCountry?' · Todo el país':''}</div>
        </div>
      </div>
      <div className="mt-3 flex gap-2">
        <a className="btn" href={`/api/contact?vendorId=${vendor.id}`} target="_blank" rel="noreferrer">{t(locale,'whatsapp')}</a>
        <Link className="btn btn-primary" href={`/proveedor/${vendor.id}`}>{t(locale,'view_vendor')}</Link>
      </div>
    </div>
  )
}
